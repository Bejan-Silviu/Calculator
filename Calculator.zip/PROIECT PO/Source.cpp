#include <iostream>
#include <string>
#include "Ecuatie.h"
#include "EcuatieSimpla.h"
#include "VerificareEcuatie.h"
#include "TransformareNumar.h"
using namespace std;


int main()
{
	string ecuatie;
	
	getline(cin, ecuatie);
	VerificareEcuatie e(ecuatie);
	Ecuatie ecx;
	ecuatie = ecx.eliminareSpatii(ecuatie);
	e.setCorectitudine(e.verificareStructuraSimpla(ecuatie));
	 e.setCorectitudine(e.verificareStructura(ecuatie));
	 
	while (ecuatie != "exit")
	{
		if (e.getCorectitudine() == 0)
		{
			cout << "Eroare. Scrie o alta ecuatie sau 'exit' pentru a iesi"<<endl;
			getline(cin, ecuatie);
			e.setCorectitudine(e.verificareStructura(ecuatie));
		}
		else
		{
			cout <<"Calculare ecuatie..."<<endl;
			Ecuatie ec;
			EcuatieSimpla ec1;
			
			
			
			ecuatie=ec1.calculEcuatieSimpla(ec.calculareEcuatie(ecuatie));
			
			if (ec1.verificarePunct(ecuatie) == 0)
			{
				TransformareNumar ec2(ecuatie);
				cout << ec2.transformareFinala(ecuatie);
			}
			else
			{
				TransformareNumar ec2(ecuatie);
				ec2.validareCifre(ecuatie);
				cout << ecuatie;
			}
		
			ecuatie = "exit";
			
		}
		
	}
	
	
	
}