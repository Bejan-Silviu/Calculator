#include "TransformareNumar.h"
#include <iostream>
#include <string>

using namespace std;
TransformareNumar::TransformareNumar()
	{
		ecuatie = "eroare";
		cifre = nullptr;
		numarcifre = 0;
	}
TransformareNumar::TransformareNumar(string ecuatie)
	{
		this->ecuatie = ecuatie;
		numarcifre = ecuatie.length();
		cifre = new int[numarcifre];
	}
TransformareNumar::TransformareNumar(const TransformareNumar& t)
	{
		this->ecuatie = t.ecuatie;
		if (t.cifre != nullptr && numarcifre > 0)
		{
			for (int i = 0; i < numarcifre; i++)
			{
				this->cifre[i] = t.cifre[i];
			}
			this->numarcifre = t.numarcifre;
		}
	}

	TransformareNumar& TransformareNumar::operator=(const TransformareNumar& t)
	{
		if (this != &t)
		{
			if (cifre != nullptr)
			{
				delete[] cifre;
				cifre = nullptr;
			}
		}
		this->ecuatie = t.ecuatie;
		if (t.cifre != nullptr && numarcifre > 0)
		{
			for (int i = 0; i < numarcifre; i++)
			{
				this->cifre[i] = t.cifre[i];
			}
			this->numarcifre = t.numarcifre;
		}
		return *this;
	}
	string TransformareNumar::getEcuatie()
	{
		return ecuatie;
	}
	void TransformareNumar::setEcuatie(string ecuatie)
	{
		if (ecuatie != "")
			this->ecuatie = ecuatie;
	}
	string TransformareNumar::transformareFinala(string ecuatie)
	{

		int ok = 1;
		int i;
		char* q;
		char c = '1';
		string rezultat = "";
		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		i = 0;

		while (i < strlen(q))
		{
			if (!(strchr(".", q[i])) && !(strchr("-", q[i])))
			{
				c = q[i];


				cifre[i] = c - '0';

			}
			else if ((strchr("-", q[i])))
			{
				cifre[i] = -2;

			}
			else if ((strchr(".", q[i])))
			{
				cifre[i] = -1;

			}

			i++;
		}



		if (cifre[strlen(q) - 4] != 0)
		{
			for (int k = 0; k <= strlen(q) - 4; k++)
			{
				if (cifre[k] != -1 && cifre[k] != -2)
					rezultat = rezultat + to_string(cifre[k]);
				else if (cifre[k] == -2)
					rezultat = rezultat + "-";
				else if (cifre[k] == -1)
					rezultat = rezultat + ".";
			}
		}
		else if (cifre[strlen(q) - 4] == 0 && cifre[strlen(q) - 5] != 0)
		{
			for (int k = 0; k <= strlen(q) - 5; k++)
			{
				if (cifre[k] != -1 && cifre[k] != -2)
					rezultat = rezultat + to_string(cifre[k]);
				else if (cifre[k] == -2)
					rezultat = rezultat + "-";
				else if (cifre[k] == -1)
					rezultat = rezultat + ".";
			}
		}
		else if (cifre[strlen(q) - 4] == 0 && cifre[strlen(q) - 5] == 0 && cifre[strlen(q) - 6] != 0)
		{
			for (int k = 0; k <= strlen(q) - 6; k++)
			{
				if (cifre[k] != -1 && cifre[k] != -2)
					rezultat = rezultat + to_string(cifre[k]);
				else if (cifre[k] == -2)
					rezultat = rezultat + "-";
				else if (cifre[k] == -1)
					rezultat = rezultat + ".";
			}
		}
		else if (cifre[strlen(q) - 4] == 0 && cifre[strlen(q) - 5] == 0 && cifre[strlen(q) - 6] == 0 &&
			cifre[strlen(q) - 7] != 0)
		{
			for (int k = 0; k <= strlen(q) - 7; k++)
			{
				if (cifre[k] != -1 && cifre[k] != -2)
					rezultat = rezultat + to_string(cifre[k]);
				else if (cifre[k] == -2)
					rezultat = rezultat + "-";
				else if (cifre[k] == -1)
					rezultat = rezultat + ".";
			}
		}

		else if (cifre[strlen(q) - 4] == 0 && cifre[strlen(q) - 5] == 0 && cifre[strlen(q) - 6] == 0 &&
			cifre[strlen(q) - 7] == 0)
		{
			for (int k = 0; k < strlen(q) - 8; k++)
			{
				if (cifre[k] != -1 && cifre[k] != -2)
					rezultat = rezultat + to_string(cifre[k]);
				else if (cifre[k] == -2)
					rezultat = rezultat + "-";
				else if (cifre[k] == -1)
					rezultat = rezultat + ".";
			}
		}


		return rezultat;




	}
	int* TransformareNumar::getcifre() {
		if (numarcifre > 0 && cifre != NULL)
		{
			int* copie = new int[numarcifre];
			for (int i = 0; i < numarcifre; i++) {
				copie[i] = cifre[i];
			}
			return copie;
		}
		else {
			return NULL;
		}
	}
	void TransformareNumar::setcifre(int* cifre, int numarcifre) {
		if (cifre != NULL && numarcifre > 0)
		{
			if (this->cifre != NULL) {
				delete[] this->cifre;
			}
			this->cifre = new int[numarcifre];
			this->numarcifre = numarcifre;
			for (int i = 0; i < numarcifre; i++)
				this->cifre[i] = cifre[i];
		}
	}
	void TransformareNumar::validareCifre(string ecuatie)
	{
		int ok = 1;
		int i;
		char* q;
		char c = '1';
		string rezultat = "";
		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		i = 0;
		for (int i = 0; i < strlen(q); i++)
		{
			if (!(strchr(".", q[i])) && !(strchr("-", q[i])))
			{
				c = q[i];


				cifre[i] = c - '0';

			}
			else if ((strchr("-", q[i])))
			{
				cifre[i] = -2;

			}

		}

	}
	bool TransformareNumar::operator!()
	{
		bool ok = this->numarcifre > 0 ? true : false;
		return ok;
	}
	TransformareNumar::~TransformareNumar()
	{
		if (cifre != nullptr)
		{
			delete[] cifre;
			cifre = nullptr;
		}
	}
	int& TransformareNumar::operator[](int index)
	{
		int solutie = -1;
		if (index >= 0 && index < numarcifre) {
			return cifre[numarcifre];
		}
		else {
			return solutie;
		}
	}

	istream& operator>>(istream& in, TransformareNumar& e)
	{
		cout << "Ecuatie:";
		in >> e.ecuatie;
		int nr;
		cout << "Numar Elemente:";
		in >> nr;
		int* v = new int[nr];
		for (int i = 0; i < nr; i++) {
			cout << "Cifra[" << i << "]=";
			in >> v[i];
		}
		e.setcifre(v, nr);
		delete[]v;
		return in;
	}
	ostream& operator<<(ostream& out, TransformareNumar e)
	{
		out << "Ecuatie " << e.ecuatie << endl;
		out << "distante";
		for (int i = 0; i < e.numarcifre; i++) {
			out << e.cifre[i] << " ";
		}
		return out;
	}

