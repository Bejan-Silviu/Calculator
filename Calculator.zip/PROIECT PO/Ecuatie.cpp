#include <iostream>
#include <string>
#include "Ecuatie.h"
using namespace std;
Ecuatie::Ecuatie()
{
	ecuatie = "eroare";
};
Ecuatie::Ecuatie(string ecuatie)
{
	this->ecuatie = ecuatie;
}
	string Ecuatie::eliminareSpatii(string ecuatie)
	{
		string copie = "";

		for (int i = 0; i < ecuatie.length(); i++)
		{

			if (!(strchr(" ", ecuatie[i])))
			{
				copie = copie + ecuatie[i];
			}
		}
		return copie;
	}
	string Ecuatie::calculareEcuatie(string ecuatie)
	{
		int ok = 1;
		char* q;
		string sp = "";


		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		double rezultat = 0;
		while (ok != 0)
		{
			ok = 0;
			for (int i = 0; i < strlen(q); i++)
			{
				if ((strchr("(", q[i])))
				{
					string rezpar = "";
					int co = 0;
					int j = i + 1;
					sp = "";
					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("^", q[j])))
						{
							string rezp = "";
							co++;
							int ps = j;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j;
							while (!(strchr("+-/*(", q[ps])))
							{
								ps--;
							}
							if ((strchr("-", q[pd + 1])))
							{
								nrdr = nrdr + "-";
								pd = pd + 2;
							}
							while (!(strchr("+-/*)#", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}

							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							nrs = stod(nrst);
							nrd = stod(nrdr);
							if ((strchr("-", q[ps])) && (strchr("(*+-/", q[ps - 1])))
							{


								nrs = nrs * (-1);

							}

							for (int k = 1; k <= nrd; k++)
								rez = rez * nrs;
							rezp = to_string(rez);
							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";

							for (int k = 0; k < ps; k++)
								temp = temp + q[k];


							temp = temp + rpputere;

							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());





						}
						j++;
					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("#", q[j])))
						{
							if (strchr("-", q[j + 1]))
								return "Eroare";
							string rezp = "";
							co++;
							int ps = j;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j;
							while (!(strchr("+-/*(", q[ps])))
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							for (int k = j + 1; k < pd; k++)
							{
								nrdr = nrdr + q[k];
							}
							if ((strchr("-", q[ps])) && (strchr("(", q[ps - 1])))
							{
								return "Eroare";

							}

							else
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

							}

							rez = pow(nrs, 1 / nrd);

							rezp = to_string(rez);

							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";

							for (int k = 0; k <= ps; k++)
								temp = temp + q[k];
							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());




						}
						j++;
					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("*", q[j])) || (strchr("/", q[j])))
						{
							string rezp = "";
							co++;
							int ps = j - 1;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j + 1;
							if ((strchr("-", q[pd])))
							{
								nrdr = nrdr + "-";
								pd++;
							}
							while (!(strchr("+-(/*", q[ps])) && ps >= 0)
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							if ((strchr("-", q[ps])) && (strchr("(", q[ps - 1])))
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

								nrs = nrs * (-1);

							}
							else
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

							}
							if ((strchr("*", q[j])))
							{
								rez = nrs * nrd;
							}
							else if ((strchr("/", q[j])))
							{
								rez = nrs / nrd;
							}
							rezp = to_string(rez);
							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";
							for (int k = 0; k < ps; k++)
								temp = temp + q[k];



							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());






						}
						j++;

					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{

						double rez = 1;
						if (((strchr("+", q[j])) || (strchr("-", q[j]))) && !((strchr("-", q[j])) && (strchr("(", q[j - 1]))))
						{
							string rezp = "";
							co++;
							int ps = j - 1;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j + 1;
							if ((strchr("-", q[pd + 1])))
							{
								nrdr = nrdr + "-";
								pd = pd + 2;
							}
							while (!(strchr("+-(/*", q[ps])) && ps > 0)
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							if ((strchr("-", q[ps])) && (strchr("(*+-/", q[ps - 1])))
							{
								nrs = stod(nrst);
								nrd = stod(nrdr);
								nrs = nrs * (-1);

							}
							else
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

							}
							if ((strchr("+", q[j])))
							{
								rez = nrs + nrd;
							}
							else if ((strchr("-", q[j])))
							{
								rez = nrs - nrd;
							}
							rezp = to_string(rez);
							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";
							for (int k = 0; k < ps; k++)
								temp = temp + q[k];


							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());
							i = 0;






						}
						j++;
					}



					while (!(strchr(")", q[j])))
					{
						j++;
					}






				}

			}

			string rezpar = "";


			for (int k = 0; k < strlen(q); k++)
			{
				if (!(strchr("()[]", q[k])))
				{
					rezpar = rezpar + q[k];
				}
				if ((strchr("[", q[k])))
				{
					rezpar = rezpar + "(";
				}
				if ((strchr("]", q[k])))
				{
					rezpar = rezpar + ")";
				}

			}

			delete[] q;
			q = nullptr;
			q = new char[rezpar.length() + 1];
			strcpy_s(q, rezpar.length() + 1, rezpar.c_str());
			for (int k = 0; k < strlen(q); k++)
			{
				if ((strchr("()[]", q[k])))
					ok++;
			}


		}

		return q;


	}
	string Ecuatie::getEcuatie()
	{
		return ecuatie;
	}
	void Ecuatie::setEcuatie(string ecuatie)
	{
		if (ecuatie != "")
			this->ecuatie = ecuatie;
	}
	bool Ecuatie::operator<(Ecuatie e) {
		return ecuatie.length() < e.ecuatie.length();
	}
	bool Ecuatie::operator>=(Ecuatie e) {
		return ecuatie.length() >= e.ecuatie.length();
	}
	istream& operator>>(istream& in, Ecuatie& e)
	{
		cout << "Ecuatie:";
		in >> e.ecuatie;
		return in;
	}
	ostream& operator<<(ostream& out, Ecuatie e)
	{
		out << "Ecuatie " << e.ecuatie << endl;
		return out;
	}
