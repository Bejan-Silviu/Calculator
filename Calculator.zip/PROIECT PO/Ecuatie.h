
#include <iostream>
#include <string>
using namespace std;
class Ecuatie
{
private:
	string ecuatie;

public:
	Ecuatie();

	Ecuatie(string ecuatie);

	string eliminareSpatii(string ecuatie);
	string calculareEcuatie(string ecuatie);
	string getEcuatie();
	void setEcuatie(string ecuatie);
	bool operator<(Ecuatie e);
	bool operator>=(Ecuatie e);
	friend istream& operator>>(istream& in, Ecuatie& e);
	friend ostream& operator<<(ostream& out, Ecuatie e);
};