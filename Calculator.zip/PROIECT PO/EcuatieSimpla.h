#include <iostream>
#include <string>
using namespace std;
class EcuatieSimpla
{
private:
	string ecuatie;

public:
	EcuatieSimpla();
	EcuatieSimpla(string ecuatie);
	string calculEcuatieSimpla(string ecuatie);
	string getEcuatie();
	void setEcuatie(string ecuatie);
	int verificarePunct(string ecuatie);
	EcuatieSimpla operator++();
	EcuatieSimpla operator++(int i);
	EcuatieSimpla operator--();
	EcuatieSimpla operator--(int i);
	friend istream& operator>>(istream& in, EcuatieSimpla& e);
	friend ostream& operator<<(ostream& out, EcuatieSimpla e);
};
