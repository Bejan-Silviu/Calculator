#pragma once
#include <iostream>
#include <string>
using namespace std;
class TransformareNumar
{
private:
	string ecuatie;
	int numarcifre;
	int* cifre;
public:
	TransformareNumar();
	TransformareNumar(string ecuatie);
	TransformareNumar(const TransformareNumar& t);
	~TransformareNumar();
	TransformareNumar& operator=(const TransformareNumar& t);
	string getEcuatie();
		void setEcuatie(string ecuatie);
		string transformareFinala(string ecuatie);
		int* getcifre();
		void setcifre(int* cifre, int numarcifre);
		void validareCifre(string ecuatie);
		bool operator!();
		int& operator[](int index);
	

		friend istream& operator>>(istream& in, TransformareNumar& e);
		friend ostream& operator<<(ostream& out, TransformareNumar e);

};