#include <iostream>
#include <string>

using namespace std;

class VerificareEcuatie
{
private:
	string ec;
	const string toatecaracterele = "1234567890+-/*^#[](). ";
	static bool corectitudine;
public:
	VerificareEcuatie();
	VerificareEcuatie(string ecuatie);
		string getecuatie();
		void setEcuatie(string ecuatie);
		bool verificareStructura(string ecuatie);
		static void setCorectitudine(bool rezultat);
		static bool getCorectitudine();
		bool verificareStructuraSimpla(string ecuatie);
		VerificareEcuatie operator+(const VerificareEcuatie& n);
		VerificareEcuatie operator*(const VerificareEcuatie& n);
		friend istream& operator>>(istream& in, VerificareEcuatie& e);
		friend ostream& operator<<(ostream& out, VerificareEcuatie e);
};

