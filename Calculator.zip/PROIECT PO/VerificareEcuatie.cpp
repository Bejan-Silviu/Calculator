#include "VerificareEcuatie.h"
#include <iostream>
#include <string>
#pragma once
using namespace std;

bool VerificareEcuatie::corectitudine = 1;
VerificareEcuatie::VerificareEcuatie()
	{
		ec = "";
	}
VerificareEcuatie::VerificareEcuatie(string ecuatie)
	{
		ec = ecuatie;
	}
	string VerificareEcuatie::getecuatie()
	{
		return ec;
	}
	void VerificareEcuatie::setEcuatie(string ecuatie)
	{
		if (ecuatie != "")
			ec = ecuatie;
	}
	bool VerificareEcuatie::verificareStructura(string ecuatie)
	{

		int pr = 0;
		int pp = 0;
		char* q;
		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		for (int i = 0; i < strlen(q); i++)
		{

			if (!(strchr(toatecaracterele.c_str(), q[i])))
				return 0;
			if ((strchr("+/*^#.", q[i])) && i == 0)
				return 0;
			if ((strchr("[]", q[i])))
				pp++;
			if ((strchr("()", q[i])))
				pr++;
			if ((strchr("+-/*^.", q[i])) != NULL && (strchr("+-/*^.", q[i + 1])) != NULL)
				return 0;
			if ((strchr("+-/*^#.", q[i])) != NULL && (strchr("#", q[i + 1])) != NULL)
				return 0;
			if ((strchr("[(", q[i])) != NULL && (strchr("+/*^.", q[i + 1])) != NULL)
				return 0;
			if ((strchr("^", q[i])) != NULL && (strchr("+-/*^#.", q[i + 1])) != NULL)
				return 0;
			if ((strchr("+-/*^#.", q[i])) != NULL && (strchr(")]", q[i + 1])) != NULL)
				return 0;
			if ((strchr("/", q[i])) != NULL && (strchr("0", q[i + 1])) != NULL && (strchr("+-/*", q[i + 2])))
				return 0;
			if (i != strlen(q) - 1)
			{
				if ((strchr(")]", q[i])) != NULL && (strchr("1234567890", q[i + 1])) != NULL)
					return 0;
				if ((strchr("1234567890", q[i])) != NULL && (strchr("[(", q[i + 1])) != NULL)
					return 0;
				if ((strchr("()", q[i])) != NULL && (strchr("()", q[i + 1])) != NULL)
					return 0;
				if ((strchr("[]", q[i])) != NULL && (strchr("[]", q[i + 1])) != NULL)
					return 0;

			}


		}
		if (pp == 0 && pr == 0)
		{
			return 1;
		}
		else if (pp != 0 && pr == 0)
			return 0;
		else if (pr != 0 && pp == 0)
		{
			int counter = 0;

			for (int i = 0; i < strlen(q); i++)
			{

				if (counter % 2 != 0 && (strchr("(", q[i])) != NULL)
					return 0;
				if (counter % 2 == 0 && (strchr(")", q[i])) != NULL)
					return 0;

				if ((strchr("(", q[i])) || (strchr(")", q[i])) != NULL)
					counter++;



			}
			if (counter % 2 != 0)
				return 0;
		}
		else if (pp != 0 && pr != 0)
		{
			int cr = 0;
			int cp = 0;
			for (int i = 0; i < strlen(q); i++)
			{
				if (cp % 2 != 0 && (strchr("[", q[i])) != NULL)
					return 0;
				if (cp % 2 == 0 && (strchr("]", q[i])) != NULL)
					return 0;
				if (cr % 2 != 0 && (strchr("(", q[i])) != NULL)
					return 0;
				if (cr % 2 == 0 && (strchr(")", q[i])) != NULL)
					return 0;

				if ((strchr("[", q[i])) || (strchr("]", q[i])) != NULL)
					cp++;

				if ((strchr("(", q[i])) || (strchr(")", q[i])) != NULL)
					cr++;
				if ((strchr("(", q[i])))
				{
					int parinchisa = 0;
					int j = i + 1;
					while (parinchisa != 1)
					{

						if ((strchr(")", q[j])))
							parinchisa = 1;
						if ((strchr("[", q[j])))
							return 0;
						j++;
					}
				}




			}
			if (cp % 2 != 0)
				return 0;
		}
		return 1;
	}
	void VerificareEcuatie::setCorectitudine(bool rezultat)
	{
		if (rezultat)
		{
			corectitudine = rezultat;
		}
		else
		{
			corectitudine = rezultat;
		}

	}
	 bool VerificareEcuatie::getCorectitudine()
	{

		return corectitudine;
	}
	bool VerificareEcuatie::verificareStructuraSimpla(string ecuatie)
	{
		int pr = 0;
		int pp = 0;
		char* q;
		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		for (int i = 0; i < strlen(q); i++)
		{

			if (!(strchr(toatecaracterele.c_str(), q[i])))
				return 0;
		}
	}
	VerificareEcuatie VerificareEcuatie::operator+(const VerificareEcuatie& n)
	{
		VerificareEcuatie copie = *this;
		copie.ec = copie.ec + "+" + n.ec;
		return copie;
	}
	VerificareEcuatie VerificareEcuatie::operator*(const VerificareEcuatie& n)
	{
		VerificareEcuatie copie = *this;
		copie.ec = copie.ec + "*" + n.ec;
		return copie;
	}
	istream& operator>>(istream& in, VerificareEcuatie& e)
	{
		cout << "Ecuatie:";
		in >> e.ec;
		return in;
	}
	ostream& operator<<(ostream& out, VerificareEcuatie e)
	{
		out << "Ecuatie " << e.ec << endl;
		return out;
	}


