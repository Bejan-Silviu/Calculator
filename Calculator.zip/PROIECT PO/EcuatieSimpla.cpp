#include "EcuatieSimpla.h"
#include <iostream>
#include <string>

using namespace std;
EcuatieSimpla::EcuatieSimpla()
	{
		ecuatie = "";

	}
EcuatieSimpla::EcuatieSimpla(string ecuatie)
	{
		this->ecuatie = ecuatie;

	}
	string EcuatieSimpla::calculEcuatieSimpla(string ecuatie)
	{
		string ecusoara = "";
		string paranteza = "(";
		ecusoara = paranteza + ecuatie;
		ecusoara = ecusoara + ")";

		int ok = 1;
		char* q;
		string sp = "";
		q = new char[ecusoara.length() + 1];
		strcpy_s(q, ecusoara.length() + 1, ecusoara.c_str());
		double rezultat = 0;
		for (int i = 0; i < strlen(q); i++)
		{
			if (strchr("-", q[i - 1]) && strchr("-", q[i]))
			{

				string temp = "";

				for (int k = 0; k < i - 1; k++)
					temp = temp + q[k];


				temp = temp + "+";

				for (int k = i + 1; k < strlen(q); k++)
					temp = temp + q[k];

				delete[] q;
				q = nullptr;
				q = new char[temp.length() + 1];
				strcpy_s(q, temp.length() + 1, temp.c_str());
			}
			if (strchr("+", q[i - 1]) && strchr("-", q[i]))
			{
				string temp = "";

				for (int k = 0; k < i - 1; k++)
					temp = temp + q[k];


				temp = temp + "-";

				for (int k = i + 1; k < strlen(q); k++)
					temp = temp + q[k];

				delete[] q;
				q = nullptr;
				q = new char[temp.length() + 1];
				strcpy_s(q, temp.length() + 1, temp.c_str());
			}

		}
		while (ok != 0)
		{
			ok = 0;
			for (int i = 0; i < strlen(q); i++)
			{
				if ((strchr("(", q[i])))
				{
					string rezpar = "";
					int co = 0;
					int j = i + 1;
					sp = "";
					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("^", q[j])))
						{
							string rezp = "";
							co++;
							int ps = j;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j;
							while (!(strchr("+-/*(", q[ps])))
							{
								ps--;
							}
							if ((strchr("-", q[pd + 1])))
							{
								nrdr = nrdr + "-";
								pd = pd + 2;
							}
							while (!(strchr("+-/*)#", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}

							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							nrs = stod(nrst);
							nrd = stod(nrdr);
							if ((strchr("-", q[ps])) && (strchr("(*+-/", q[ps - 1])))
							{
								nrs = nrs * (-1);
							}

							for (int k = 1; k <= nrd; k++)
								rez = rez * nrs;
							rezp = to_string(rez);

							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";

							for (int k = 0; k < ps; k++)
								temp = temp + q[k];


							temp = temp + rpputere;

							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());





						}
						j++;
					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("#", q[j])))
						{
							if (strchr("-", q[j + 1]))
								return "Eroare";
							string rezp = "";
							co++;
							int ps = j;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j;
							while (!(strchr("+-/*(", q[ps])))
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							for (int k = j + 1; k < pd; k++)
							{
								nrdr = nrdr + q[k];
							}
							if ((strchr("-", q[ps])) && (strchr("(", q[ps - 1])))
							{
								return "Eroare";

							}

							else
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

							}

							rez = pow(nrs, 1 / nrd);

							rezp = to_string(rez);

							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";

							for (int k = 0; k <= ps; k++)
								temp = temp + q[k];
							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());




						}
						j++;
					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{
						double rez = 1;
						if ((strchr("*", q[j])) || (strchr("/", q[j])))
						{
							string rezp = "";
							co++;
							int ps = j - 1;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j + 1;
							if ((strchr("-", q[pd])))
							{
								nrdr = nrdr + "-";
								pd++;
							}
							while (!(strchr("+-(/*", q[ps])))
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							if ((strchr("-", q[ps])) && (strchr("(", q[ps - 1])))
							{
								nrs = stod(nrst);
								nrd = stod(nrdr);

								nrs = nrs * (-1);

							}
							else
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

							}
							if ((strchr("*", q[j])))
							{
								rez = nrs * nrd;
							}
							else if ((strchr("/", q[j])))
							{
								rez = nrs / nrd;
							}
							rezp = to_string(rez);
							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";
							for (int k = 0; k < ps; k++)
								temp = temp + q[k];


							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());






						}
						j++;

					}

					j = i + 1;
					while (!(strchr(")", q[j])))
					{

						double rez = 1;
						if (((strchr("+", q[j])) || (strchr("-", q[j]))) && !((strchr("-", q[j])) && (strchr("(", q[j - 1]))))
						{
							string rezp = "";
							co++;
							int ps = j - 1;
							string nrst = "";
							string nrdr = "";
							double nrs;
							double nrd;
							int pd = j + 1;
							if ((strchr("-", q[pd + 1])))
							{
								nrdr = nrdr + "-";
								pd = pd + 2;;
							}
							while (!(strchr("+-(/*", q[ps])) && ps >= 0)
							{
								ps--;
							}
							while (!(strchr("+-/*)", q[pd])))
							{
								pd++;
							}

							for (int k = ps + 1; k < j; k++)
							{
								nrst = nrst + q[k];

							}
							if ((strchr("-", q[j + 1])))
							{
								for (int k = j + 2; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}
							else
							{
								for (int k = j + 1; k < pd; k++)
								{
									nrdr = nrdr + q[k];
								}
							}

							if ((strchr("-", q[ps])) && (strchr("(*+-/", q[ps - 1])))
							{

								nrs = stod(nrst);
								nrd = stod(nrdr);

								nrs = nrs * (-1);

							}
							else
							{

								nrs = stod(nrst);

								nrd = stod(nrdr);

							}
							if ((strchr("+", q[j])))
							{
								rez = nrs + nrd;
							}
							else if ((strchr("-", q[j])))
							{
								rez = nrs - nrd;
							}
							rezp = to_string(rez);
							char* rpputere;
							rpputere = new char[rezp.length() + 1];
							strcpy_s(rpputere, rezp.length() + 1, rezp.c_str());
							string temp = "";
							for (int k = 0; k < ps; k++)
								temp = temp + q[k];


							temp = temp + rpputere;
							for (int k = pd - 1; k < strlen(q); k++)
								temp = temp + q[k];

							delete[] q;
							q = nullptr;
							q = new char[temp.length() + 1];
							strcpy_s(q, temp.length() + 1, temp.c_str());
							i = 0;






						}
						j++;
					}



					while (!(strchr(")", q[j])))
					{
						j++;
					}






				}

			}

			string rezpar = "";


			for (int k = 0; k < strlen(q); k++)
			{
				if (!(strchr("()[]", q[k])))
				{
					rezpar = rezpar + q[k];
				}
				if ((strchr("[", q[k])))
				{
					rezpar = rezpar + "(";
				}
				if ((strchr("]", q[k])))
				{
					rezpar = rezpar + ")";
				}

			}

			delete[] q;
			q = nullptr;
			q = new char[rezpar.length() + 1];
			strcpy_s(q, rezpar.length() + 1, rezpar.c_str());
			for (int k = 0; k < strlen(q); k++)
			{
				if ((strchr("()[]", q[k])))
					ok++;
			}


		}
		return q;
	}
	string EcuatieSimpla::getEcuatie()
	{
		return ecuatie;
	}
	void EcuatieSimpla::setEcuatie(string ecuatie)
	{
		if (ecuatie != "")
			this->ecuatie = ecuatie;
	}
	int EcuatieSimpla::verificarePunct(string ecuatie)
	{
		int ok = 1;
		char* q;
		string sp = "";
		q = new char[ecuatie.length() + 1];
		strcpy_s(q, ecuatie.length() + 1, ecuatie.c_str());
		for (int i = 0; i < strlen(q); i++)
		{
			if (strchr(".", q[i]))
				ok = 0;
		}
		return ok;
	}
	EcuatieSimpla EcuatieSimpla::operator++()
	{
		double rezultat;
		rezultat = stod(ecuatie);
		rezultat++;
		ecuatie = to_string(rezultat);

		return *this;
	}
	EcuatieSimpla EcuatieSimpla::operator++(int i)
	{
		double rezultat;
		EcuatieSimpla copie = *this;
		rezultat = stod(ecuatie);
		rezultat++;
		ecuatie = to_string(rezultat);
		return copie;
	}
	EcuatieSimpla EcuatieSimpla::operator--()
	{
		double rezultat;
		rezultat = stod(ecuatie);
		rezultat--;
		ecuatie = to_string(rezultat);

		return *this;
	}
	EcuatieSimpla EcuatieSimpla::operator--(int i)
	{
		double rezultat;
		EcuatieSimpla copie = *this;
		rezultat = stod(ecuatie);
		rezultat--;
		ecuatie = to_string(rezultat);
		return copie;
	}
	istream& operator>>(istream& in, EcuatieSimpla& e)
	{
		cout << "Ecuatie:";
		in >> e.ecuatie;
		return in;
	}
	ostream& operator<<(ostream& out, EcuatieSimpla e)
	{
		out << "Ecuatie " << e.ecuatie << endl;
		return out;
	}
